import scaleMixin from './scale';

const ImageScale = {};

scaleMixin(ImageScale);

export default ImageScale;
