import ImgClip from './clip';

export default ImgClip;
