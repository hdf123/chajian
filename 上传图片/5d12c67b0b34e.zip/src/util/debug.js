export function warn(msg) {
    // 模板字符串
    console.error(`[EJS error]: ${msg}`);
}

export function log(msg) {
    console.log(`[EJS log]: ${msg}`);
}